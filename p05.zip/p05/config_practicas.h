/*
 * config_practicas.h
 *
 *  Created on: 10/03/2015
 *      Author: jctejero
 */

#ifndef CONFIG_PRACTICAS_H_
#define CONFIG_PRACTICAS_H_
/****************************************************************************/
/***        Include files                                                 ***/
/****************************************************************************/
#include	"utils_domoBoard.h"
#include	"DomoBoard/domoBoard.h"

/****************************************************************************/
/***        Exported Functions                                            ***/
/****************************************************************************/
void config_interruptores(void);






#endif /* CONFIG_PRACTICAS_H_ */
