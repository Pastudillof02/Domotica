/*
 * types.h
 *
 *  Created on: 1 mar 2023
 *      Author: jctejero
 */

#ifndef TYPES_H_
#define TYPES_H_

typedef void (*TNotifyEvent)(void *); //using TNotifyEvent = void(*)(void *);

using void_callback_f = void (*)();  //typedef void (*void_callback_f)();


#endif /* TYPES_H_ */
